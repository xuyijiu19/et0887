const fs = require("node:fs");

fs.writeFile("./myfile.txt", "Hello World", (err) => {
    if(err){
        console.error(err);
    }
    else {
        console.log("done");
    }
});