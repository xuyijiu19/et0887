const express = require("express");

const app = express();

// 1
//app.use("/public", express.static("public"));

// 2
app.use(["/public", "/www"], express.static("public"));

// 4
app.get("/ACCOUNT/:id", (req, res, next) => {
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");
    res.end("<h1>User ID (using :id) : " + req.params.id + "</h1>"); 
});

// 5
app.get("/product/:brand/:model", (req, res, next) => {
    const {brand, model} = req.params;
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");
    res.end("<h1>brand : " + brand + "</h1><h2>model : " + model + "</h2>"); 
});

// 0
app.use((req, res, next) => {
	res.statusCode = 400;
	res.setHeader("Content-Type", "text/html");
	res.end("<h1>Invalid Request</h1>");
});

app.listen(8000, "localhost");
