function f(a, b, c){
    let d = a+1, e = b+1, f = c+1;
    return [d, e, f];
}

console.log(f(-1, -1, -1));
console.log(f(99, 49, 19));
console.log(f(100, 200, 300));
