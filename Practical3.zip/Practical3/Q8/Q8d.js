const fs = require("node:fs");

function makeBoxOfficeObject() {
	let boxOfficeObjectArray = [];
	const data = fs.readFileSync("data.csv", "utf8");
	const lines = data.split("\n");
	const header = lines[0].split(",");
	for (let i = 1; i < lines.length; i++) {
		const columns = lines[i].split(",");
		let boxOffice = {};
		for (let j = 0; j < columns.length; j++) {
			boxOffice[header[j]] = columns[j];
		}
		boxOfficeObjectArray.push(boxOffice);
	}
	return boxOfficeObjectArray;
}

const boxOfficeobj = makeBoxOfficeObject();
console.log(boxOfficeobj);

