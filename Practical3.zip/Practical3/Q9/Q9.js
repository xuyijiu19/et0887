const text =
	"Peter Piper picked a peck of pickled peppers.  A peck of pickled peppers Peter Piper picked.  If Peter Piper picked a peck of pickled peppers, where’s the peck of pickled peppers Peter Piper picked?";

const searchString = "jim";
let startingPos = 0;
let count = 0;
    while(1){
        let positionFound = text.indexOf(searchString, startingPos);
        if(positionFound != -1){
            startingPos = positionFound +1;
            count++;
        }
        else {
            console.log(searchString + " occurs " + count + " times");
            break;
        }

    }