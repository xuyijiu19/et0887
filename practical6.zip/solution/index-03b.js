const express = require("express");
// install body-parser
const bodyParser = require('body-parser');

const app = express();
const messages = [];

app.use(bodyParser.urlencoded());

let grades = [ 
{id: 1234567, module: "ET0123", grade: "A"},
{id: 1234567, module: "ET0555", grade: "B"},
{id: 2345678, module: "ET0123", grade: "C"},
{id: 2345678, module: "ET0555", grade: "D"}
];

// 2
app.use(["/public", "/www"], express.static("public"));

// 3
app.get("/MSG", (req, res, next) => {
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");
    res.end("<h1>Message : " + req.query.msg + "</h1>"); 
});

app.post("/MSG", (req, res, next) => {
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");
    res.end("<h1>Message : " + req.body.msg + "</h1>"); 
});

// message stack
app.post("/msglist", (req, res, next) => {
    messages.push(req.body.msg);
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");
    let content = "<ul>";
    for(const message of messages){
        content += "<li>" + message + "</li>";
    }
    content += "</ul>";
    res.end(content);
});

app.post("/grade", (req, res, next) => {

    let id = req.body.id; 
    module = req.body.module;
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");

    let grade = "";
    for(let i = 0; i < grades.length; i++){
        console.log(grades[i]['id']);
        if(grades[i]['id'] == id && grades[i]['module'] == module){
            grade = grades[i]['grade'];
        }
    }
    if(grade == ""){
        res.end("<h1>Not found</h1>"); 
    }
    else {
        res.end("<h1>id : " + id + "</h1><h2>module : " + module + "</h2><h3>Grade: " + grade + "</h3>"); 
    }
});

// 0
app.get((req, res, next) => {
	res.statusCode = 400;
	res.setHeader("Content-Type", "text/html");
	res.end("<h1>Invalid Request</h1>");
});

app.listen(8000, "localhost");
