function subtract(a, b){
	if(a > b)
		return a - b;
	else 
		return b - a
}

function stringify(a){
	return "Result: " + a;
}

console.log(subtract(12, 10));
console.log(stringify(subtract(10, 12)));