function swap(a, b) {
    return a > b ? [b, a] : [a, b];
}

function BubleSort(scores) {
    for (let i = 0; i < scores.length; i++) {
        for (let j = 0; j < scores.length - 1; j++) {
            [scores[j], scores[j + 1]] = swap(scores[j], scores[j + 1]);
        }
    }
    return scores;
}

console.log(BubleSort([5, 4, 3, 2, 1]));
