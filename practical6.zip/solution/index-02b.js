const express = require("express");

const app = express();

let grades = [ 
{id: 1234567, module: "ET0123", grade: "A"},
{id: 1234567, module: "ET0555", grade: "B"},
{id: 2345678, module: "ET0123", grade: "C"},
{id: 2345678, module: "ET0555", grade: "D"}
];

// 1
//app.use("/public", express.static("public"));

// 2
app.use(["/public", "/www"], express.static("public"));

// 4
app.get("/ACCOUNT/:id", (req, res, next) => {
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");
    res.end("<h1>User ID (using :id) : " + req.params.id + "</h1>"); 
});

// 5
app.get("/product/:brand/:model", (req, res, next) => {
    const {brand, model} = req.params;
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");
    res.end("<h1>brand : " + brand + "</h1><h2>model : " + model + "</h2>"); 
});

app.get("/student/:id/:module", (req, res, next) => {
    const {id, module} = req.params;
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");
    let grade = "";
    for(let i = 0; i < grades.length; i++){
        console.log(grades[i]['id']);
        if(grades[i]['id'] == id && grades[i]['module'] == module){
            grade = grades[i]['grade'];
        }
    }
    if(grade == ""){
        res.end("<h1>Not found</h1>"); 
    }
    else {
        res.end("<h1>id : " + id + "</h1><h2>module : " + module + "</h2><h3>Grade: " + grade + "</h3>"); 
    }
});

// 0
app.use((req, res, next) => {
	res.statusCode = 400;
	res.setHeader("Content-Type", "text/html");
	res.end("<h1>Invalid Request</h1>");
});

app.listen(8000, "localhost");
