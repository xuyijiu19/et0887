const fs = require("node:fs");

const data = fs.readFileSync("myfile.txt", "utf-8");
console.log("Content: " + data);
