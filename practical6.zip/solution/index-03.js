const express = require("express");
// install body-parser
const bodyParser = require('body-parser');

const app = express();
const messages = [];

app.use(bodyParser.urlencoded());

// 2
app.use(["/public", "/www"], express.static("public"));

// 3
app.get("/MSG", (req, res, next) => {
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");
    res.end("<h1>Message : " + req.query.msg + "</h1>"); 
});

app.post("/MSG", (req, res, next) => {
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");
    res.end("<h1>Message : " + req.body.msg + "</h1>"); 
});

// message stack
app.post("/msglist", (req, res, next) => {
    messages.push(req.body.msg);
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");
    let content = "<ul>";
    for(const message of messages){
        content += "<li>" + message + "</li>";
    }
    content += "</ul>";
    res.end(content);
});

// 0
app.get((req, res, next) => {
	res.statusCode = 400;
	res.setHeader("Content-Type", "text/html");
	res.end("<h1>Invalid Request</h1>");
});

app.listen(8000, "localhost");
