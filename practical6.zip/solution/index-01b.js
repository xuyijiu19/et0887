const express = require("express");

const app = express();

// 1
app.use((req, res, next) => {
    console.log("Middleware 1 " + req.url);
    next();
});

// 2
app.use((req, res, next) => {
    console.log("Middleware 2 " + req.url);
    if(req.url == "/hello"){
        res.statusCode = 200;
        res.end("<h1>Hello World</h1>");    
    }
    else {
        next();
    }
});

app.use((req, res, next) => {
    console.log("Middleware 3 " + req.url);
    if(req.url == "/hello123"){
        res.statusCode = 200;
        res.end("<h1>your name</h1>");    
    }
    else {
        next();
    }
});

// 3
app.use((req, res, next) => {
    console.log("Middleware 3 " + req.url);
    res.statusCode = 400;
    res.end("<h1>invalid request: " + req.url + "</h1>"); 
});


app.listen(8000, "localhost");
