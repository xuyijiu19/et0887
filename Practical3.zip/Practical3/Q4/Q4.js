function swap(a, b){
    return (a > b)? [b, a] : [a, b];
}

let scores = [67, 80, 56, 95, 80, 75, 75, 92, 91, 77];

console.log(scores);

for(let i = 0; i < scores.length; i++){
    for(let j = 0; j < scores.length - 1; j++){
        [scores[j], scores[j+1]] = swap(scores[j], scores[j+1]);
    }
}

console.log(scores);