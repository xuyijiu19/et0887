const fs = require("node:fs");

let data;

try {
    data = fs.readFileSync("data.csv", "utf-8");
}
catch (err){
    console.error(err);
    return;
}
const lines = data.split("\n");
for (const line of lines) {
	const columns = line.split(",");
	for (const column of columns) {
		console.log(column);
	}
}
